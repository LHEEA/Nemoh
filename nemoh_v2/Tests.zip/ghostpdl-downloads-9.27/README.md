# ghostpdl 9.27

See:
https://ghostscript.com/doc/9.27/Readme.htm

Any bugs should be reported to:
https://bugs.ghostscript.com/

(Please do not use the github.com issue tracker).
